VELOCITY RIFT - Windows

1. Extract this whole folder (keep VelocityRift.exe and resources.neu together).
2. Double-click VelocityRift.exe to play. No install needed.

Needs Windows 10 or 11 (uses the built-in Microsoft Edge WebView2, already present on most PCs).
If a blank window appears, install "WebView2 Runtime" from Microsoft and run again.
If Windows SmartScreen warns about an unknown app, click "More info" > "Run anyway".
If Windows Firewall asks about network access, click "Allow" (needed for playing with friends).

PLAY WITH FRIENDS (up to 6 players)
- Everyone needs an internet connection. Friends can use this app or the website/phone version.
- One player clicks "Play with friends" > "Create room" and gets a 6-digit code.
- Friends click "Play with friends" > "Join a room" and type the code.
- When the host starts with fewer than 6 players, the game asks whether to fill the empty spots with bots.
- The app, the website and the phone version all share the same rooms, so anyone can join a code.
- Some strict office or school networks block direct player-to-player connections. If a friend cannot join, try a home network or mobile hotspot.

Single-player works fully offline.

Controls: W/Up throttle, S/Down brake, A/D steer, Space drift, Shift nitro,
C camera, R reset car, P pause, M music, L language (English / Tamil). Gamepad works too.
In the garage: drag the car to rotate it, scroll to zoom.
